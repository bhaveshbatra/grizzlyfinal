package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.cognizant.entity.Product;
import com.cognizant.entity.Vendor;
import com.cognizant.service.ProductService;

@Controller
public class VendorController {
	@Autowired
	private ProductService productService;
	
	@Autowired@Qualifier("ProductValidator")
	private Validator productvalidator;
	
	@Autowired@Qualifier("VendorValidator")
	private Validator vendorvalidator;
	

	
	
	@RequestMapping(value="vendorform.htm",method=RequestMethod.GET)
	public String loadVendorForm(){
		return "vendorform";
	}
	@RequestMapping(value="updateproduct.htm",method=RequestMethod.POST)
	public ModelAndView persistProduct(@ModelAttribute("product")Product product,Errors errors){
		
		ModelAndView mv=new ModelAndView();

		ValidationUtils.invokeValidator(productvalidator, product, errors);
		if(errors.hasErrors()){
			mv.setViewName("vendorform");
		}else{
		boolean productPersist=productService.persistProduct(product);
		
		if(productPersist){
			mv.addObject("status","Product successfully registered");
		}else{
			mv.addObject("status","Product registration failed");
		}

		mv.setViewName("vendorform");
		}
		return mv;
	}
	
	
	@ModelAttribute("product")
	public Product createCommandObject(){
		Product product=new Product();
		product.setProductId(0);
		product.setProductName("Please type product name");
		
		return product;
	}
	@ModelAttribute("vendor")
	public Vendor createVendorObject(){
		Vendor vendor=new Vendor();
		return vendor;
		
	}
	
	@RequestMapping(value="vendorindex.htm",method=RequestMethod.GET)
	public String loadLoginForm(){
		return "vendorlogin";
	}
	@RequestMapping(value="dovendorLogin.htm",method=RequestMethod.POST)
	public ModelAndView doLogin(@ModelAttribute("vendor") Vendor vendor,Errors errors){
		ValidationUtils.invokeValidator(vendorvalidator, vendor, errors);
		ModelAndView mv=new ModelAndView();
		if(errors.hasErrors()){
			mv.setViewName("vendorlogin");
		}else{

		
		List<Product> productList=productService.getAllProducts();
		mv.addObject("productList",productList);
		mv.setViewName("vendorform");
		}
		return mv;
	}

}
