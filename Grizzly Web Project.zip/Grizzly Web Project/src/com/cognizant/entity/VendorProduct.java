package com.cognizant.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Vendorpro")

public class VendorProduct {
	
	@Id
	@Column(name="vendor_Id")
	private int vendorId;

	@Column(name="vendor_quantity")
	private int quantity;
	
	
	@OneToMany(cascade=CascadeType.ALL,targetEntity=Product.class)
	private Product product;


	public int getVendorId() {
		return vendorId;
	}


	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}





	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}


	@Override
	public String toString() {
		return "VendorProduct [vendorId=" + vendorId + ", quantity=" + quantity + ", product=" + product + "]";
	}

}
