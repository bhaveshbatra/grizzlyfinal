package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cognizant.dao.VendorLoginDAO;
import com.cognizant.entity.Vendor;

@Service("VendorLoginServiceImpl")
public class VendorLoginServiceImpl implements VendorLoginService {

	@Autowired
	private VendorLoginDAO vendorLoginDAO;
	
	@Override
	public boolean doLogin(Vendor vendor) {
		// TODO Auto-generated method stub
		return vendorLoginDAO.doLogin(vendor);
	}

}
