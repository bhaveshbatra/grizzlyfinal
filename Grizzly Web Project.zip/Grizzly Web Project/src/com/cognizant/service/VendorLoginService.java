package com.cognizant.service;


import com.cognizant.entity.Vendor;

public interface VendorLoginService {
	
	public boolean doLogin(Vendor vendor);

}
