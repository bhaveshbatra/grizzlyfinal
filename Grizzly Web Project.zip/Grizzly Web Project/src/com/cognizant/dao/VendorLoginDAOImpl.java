package com.cognizant.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.cognizant.entity.Vendor;
@Repository("VendorDAOImpl")
public class VendorLoginDAOImpl implements VendorLoginDAO{
	@Autowired
	private SessionFactory sessionFactory;
	@Override
	public boolean doLogin(Vendor vendor) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Query query=
				session.createQuery("select o from Vendor o where o.userName=:username and o.password=:password");
		query.setParameter("username", vendor.getUserName());
		query.setParameter("password", vendor.getPassword());
		List<Vendor> vendorList=query.list();
		System.out.println(vendorList);
		if(vendorList.isEmpty())
			return false;
		else
		return true;
	}

}
